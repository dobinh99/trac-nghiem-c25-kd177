# Trắc nghiệm — Full Project

This is a ready-to-deploy static quiz web app.

## Structure
- index.html
- assets/
  - style.css
  - script.js
  - images/
    - background-dragon.jpg (placeholder, replace with your image)
  - sounds/
    - timeout.mp3 (placeholder, replace with an alarm mp3)
  - questions.json (sample questions)

## Deploy
1. Create a GitHub repository.
2. Upload all files preserving folders.
3. Enable GitHub Pages in repository Settings -> Pages -> Deploy from a branch -> main / root.
4. Wait a minute and open `https://<your-username>.github.io/<repo-name>/`

## Notes
- Replace placeholder image and sound with actual assets for best result.
- Add more questions in `assets/script.js` or `assets/questions.json`.
