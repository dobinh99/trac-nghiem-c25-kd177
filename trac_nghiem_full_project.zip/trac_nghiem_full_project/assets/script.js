// assets/script.js - quiz logic (multi-correct supported with '*' marker)

// Load questions here or from an external JSON file (assets/questions.json)
// Each question: { text: '...', A: '...', B: '...', C: '...', D: '...', correct: ['A','C'] }
let store = [
  { text: 'Which of these are prime numbers under 6?', A: '2*', B: '3*', C: '4', D: '5*', correct: ['A','B','D'] },
  { text: 'Which are vowels?', A: 'A*', B: 'B', C: 'E*', D: 'F', correct: ['A','C'] },
  { text: 'Select even numbers', A: '1', B: '2*', C: '3', D: '4*', correct: ['B','D'] },
  // add more questions here...
];

// UI elements
const totalCountEl = document.getElementById('totalCount');
const numQEl = document.getElementById('numQ');
const timeMinEl = document.getElementById('timeMin');
const startBtn = document.getElementById('startBtn');
const resetBtn = document.getElementById('resetBtn');
const exportBtn = document.getElementById('exportBtn');
const quizArea = document.getElementById('quizArea');
const timerEl = document.getElementById('timer');
const submitBtn = document.getElementById('submitBtn');
const resultArea = document.getElementById('resultArea');
const alarmSound = document.getElementById('alarmSound');

function renderCounts(){
  totalCountEl.textContent = store.length;
}
renderCounts();

// helper to deep copy
function shuffle(arr){ return arr.slice().sort(()=>Math.random()-0.5); }

let currentQuiz = [];
let userAnswers = [];
let timerInterval = null;
let remaining = 0;

startBtn.addEventListener('click', ()=>{
  if(store.length === 0){ alert('Kho câu trống. Vui lòng thêm câu.'); return; }
  const n = Math.min(store.length, parseInt(numQEl.value) || 50);
  const tmin = parseInt(timeMinEl.value) || 60;
  currentQuiz = shuffle(store).slice(0, n);
  userAnswers = currentQuiz.map(()=>[]);
  renderQuiz();
  startTimer(tmin*60);
});

resetBtn.addEventListener('click', ()=>{
  if(confirm('Reset bài thi hiện tại?')) {
    clearInterval(timerInterval);
    quizArea.innerHTML = '';
    timerEl.textContent = '--:--';
    resultArea.innerHTML = '';
  }
});

exportBtn.addEventListener('click', ()=>{
  const data = JSON.stringify(store, null, 2);
  const blob = new Blob([data], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = 'questions_export.json'; a.click();
  URL.revokeObjectURL(url);
});

function renderQuiz(){
  quizArea.innerHTML = '';
  currentQuiz.forEach((q,i)=>{
    const card = document.createElement('div'); card.className = 'questionCard';
    const title = document.createElement('div'); title.className='qTitle'; title.textContent = `Câu ${i+1}. ${q.text}`;
    const opts = document.createElement('div'); opts.className='opts';
    ['A','B','C','D'].forEach(k=>{
      const option = document.createElement('label'); option.className='opt'; option.id = `q${i}_${k}`;
      const input = document.createElement('input'); input.type='checkbox'; input.name=`q${i}`; input.value = k;
      input.addEventListener('change', ()=> {
        const checked = Array.from(document.querySelectorAll(`input[name=q${i}]:checked`)).map(x=>x.value);
        userAnswers[i] = checked;
      });
      const txt = document.createElement('span'); txt.textContent = `${k}. ${q[k]}`;
      option.appendChild(input); option.appendChild(txt); opts.appendChild(option);
    });
    card.appendChild(title); card.appendChild(opts); quizArea.appendChild(card);
  });
}

function startTimer(seconds){
  clearInterval(timerInterval);
  remaining = seconds;
  updateTimer();
  timerInterval = setInterval(()=>{
    remaining--; updateTimer();
    if(remaining < 0){
      clearInterval(timerInterval);
      autoSubmit();
    }
  },1000);
}

function updateTimer(){
  if(remaining < 0){ timerEl.textContent = '00:00'; return; }
  const m = Math.floor(remaining/60); const s = remaining%60;
  timerEl.textContent = `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
}

function arraysEqual(a,b){ if(a.length!==b.length) return false; const A=[...a].sort(); const B=[...b].sort(); return A.every((v,i)=>v===B[i]); }

submitBtn.addEventListener('click', ()=>{
  clearInterval(timerInterval);
  grade();
});

function autoSubmit(){
  if(alarmSound) try{ alarmSound.play(); }catch(e){/*ignored*/}
  resultArea.innerHTML = '<div style="color:#b91c1c;font-weight:700">Hết giờ — tự động nộp bài</div>';
  grade();
}

function grade(){
  let rawCorrect = 0;
  currentQuiz.forEach((q,i)=>{
    const user = userAnswers[i] || [];
    // compute correct from q (support when provided as strings with '*' or explicit array)
    let correct = [];
    if(Array.isArray(q.correct) && q.correct.length>0){ correct = q.correct.slice(); }
    else {
      // detect '*' marked options
      ['A','B','C','D'].forEach(k=>{
        if(String(q[k] || '').endsWith('*')) correct.push(k);
      });
    }
    // mark options
    ['A','B','C','D'].forEach(k=>{
      const el = document.getElementById(`q${i}_${k}`);
      if(!el) return;
      el.classList.remove('correct','wrong');
      const checked = user.includes(k);
      const should = correct.includes(k);
      if(should) el.classList.add('correct');
      if(checked && !should) el.classList.add('wrong');
    });
    if(arraysEqual(user, correct)) rawCorrect++;
  });
  const score = rawCorrect * 0.2; // mỗi câu 0.2 điểm, 50 câu = 10 điểm
  resultArea.innerHTML = `Kết quả: <b>${score.toFixed(2)} / 10 điểm</b> — Đúng ${rawCorrect} / ${currentQuiz.length} câu`;
}
