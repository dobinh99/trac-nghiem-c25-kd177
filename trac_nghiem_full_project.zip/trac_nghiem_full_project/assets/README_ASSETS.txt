ASSETS folder
- images/background-dragon.jpg : background image used by the site. Replace with any jpg/png you like.
- sounds/timeout.mp3 : alarm sound played when time runs out. Replace with your mp3.

Note: If you upload to GitHub, place the files in the exact path: assets/images/background-dragon.jpg and assets/sounds/timeout.mp3
